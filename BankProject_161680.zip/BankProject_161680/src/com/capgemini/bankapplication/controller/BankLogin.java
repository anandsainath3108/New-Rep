package com.capgemini.bankapplication.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.capgemini.bankapplication.entity.Account;
import com.capgemini.bankapplication.entity.Transaction;
import com.capgemini.bankapplication.exception.AccountException;
import com.capgemini.bankapplication.service.AccountServiceImpl;

public class BankLogin {

	public static void main(String[] args) throws IOException, AccountException {
		// TODO Auto-generated method stub
		Account account = new Account();
		AccountServiceImpl service = new AccountServiceImpl();
	while (true) {

		System.out.println("------------------------------------------------------------------\n");
		System.out.println("Welcome to UTI Bank Limited\n");
		System.out.println("------------------------------------------------------------------");
		System.out.println("1. Login");
		System.out.println("2. Create new Account");
		System.out.println("3. Exit");

		Scanner sc = new Scanner(System.in);
		int Choice = sc.nextInt();

		switch (Choice) {
		
		
		//Login
		case 1:
		    System.out.println("Please Enter your Account Number, Username and Password to proceed");
		    		    
		    Long accountNo1;
		    System.out.println("Please Enter your Account Number");
		    accountNo1 = sc.nextLong();
		    
		    String userName1;
		    System.out.println("Please Enter your Username");
		    userName1 = sc.next();
		    
		    String password1;
		    System.out.println("Please Enter your Password");
		    password1 = sc.next();
		    account = service.displayAccount(accountNo1);
		    if(userName1.equals(account.getUsername()) && password1.equals(account.getPassword())) {
		    	while (true) {
		    	System.out.println("Welcome:" + account.getName());
		    	System.out.println("1. Show Balance");
				System.out.println("2. Deposit");
				System.out.println("3. Withdraw");
				System.out.println("4. Fund Transfer");
				System.out.println("5. Print Transaction");
				System.out.println("6. Exit");
		    	System.out.println("Choose the option to proceed with");
		    	int choice = sc.nextInt();
		    	switch (choice) {
				
				//Show Balance
				case 1:	
				System.out.println("Availaible balance in " + account.getAccountNo() + " is Rs." + account.getBalance());
				break;
				
				//Deposit
				case 2: 
					try {
						Transaction transaction2 = new Transaction();
						System.out.println("You need to enter the Amount to be deposited");
						System.out.println("------------------------------------------------------------------");
						System.out.println("Enter the amount to be deposited");
						Double depositAmount = sc.nextDouble();
		                if(depositAmount>0){
						// Generating utrNo
						Random rnd2 = new Random();
						Integer utr2 = 10000000 + rnd2.nextInt(90000000);
						Long utrNo2 = (long) utr2;
						transaction2.setUtrNo(utrNo2);

						// Setting AccountNo
						transaction2.setAccountNoCr(account.getAccountNo());

						// Setting Deposit Amount
						transaction2.setTransferAmt(depositAmount);

						// Setting Date and time.
						LocalDate date2 = LocalDate.now();
						transaction2.setDate(date2);

						// Setting Transaction type.
						String Transactiontype2 = "Cr.";
						transaction2.setTransactiontype(Transactiontype2);

						Transaction depositTransaction = service.deposit(depositAmount, transaction2);
						System.out.println("Transaction Details are:" + depositTransaction);
		                }
		                else {
		                	System.out.println("Enter a valid Amount to be deposited");
		                }
						}catch (Exception e) {
							// TODO: handle exception
			                System.err.println("Enter a valid Account Number");
							}
						break;
				case 3: 
					try {
						Transaction transaction3 = new Transaction();
						System.out.println("You need to enter the Amount to be withdrawn");
						System.out.println("------------------------------------------------------------------");
						System.out.println("Enter the amount to be withdrawn");
						Double withdrawAmount = sc.nextDouble();
		                if(withdrawAmount>0 && account.getBalance()-withdrawAmount>0){
						// Generating utrNo
						Random rnd3 = new Random();
						Integer utr3 = 10000000 + rnd3.nextInt(90000000);
						Long utrNo3 = (long) utr3;
						transaction3.setUtrNo(utrNo3);

						// Setting AccountNo
						transaction3.setAccountNoDr(account.getAccountNo());

						// Setting Deposit Amount
						transaction3.setTransferAmt(withdrawAmount);

						// Setting Date and time.
						LocalDate date3 = LocalDate.now();
						transaction3.setDate(date3);

						// Setting Transaction type.
						String Transactiontype3 = "Cr.";
						transaction3.setTransactiontype(Transactiontype3);

						Transaction withdrawTransaction = service.withdraw(withdrawAmount, transaction3);
						System.out.println("Transaction Details are:" + withdrawTransaction);
		                }
		                else {
		                	System.out.println("Enter a valid Amount to be withdrawn / Your balance is low.");
		                }
						}catch (Exception e) {
							// TODO: handle exception
			                System.err.println("Enter a valid Account Number");
							}
						break;
				case 4: 
					try {
						Transaction transaction4 = new Transaction();
						System.out.println("You need to enter the Credit account Number and Amount to be Transferred");
						System.out.println("------------------------------------------------------------------");
						System.out.println("Enter the Credit Account Number");
						Long accountNoCr = sc.nextLong();
						System.out.println("Enter the amount to be Transferred");
						Double withdrawAmount = sc.nextDouble();
		                if(withdrawAmount>0 && account.getBalance()-withdrawAmount>0){
						// Generating utrNo
						Random rnd4 = new Random();
						Integer utr4 = 10000000 + rnd4.nextInt(90000000);
						Long utrNo4 = (long) utr4;
						transaction4.setUtrNo(utrNo4);

						// Setting AccountNo
						transaction4.setAccountNoCr(accountNoCr);
						transaction4.setAccountNoDr(account.getAccountNo());

						// Setting Deposit Amount
						transaction4.setTransferAmt(withdrawAmount);

						// Setting Date and time.
						LocalDate date4 = LocalDate.now();
						transaction4.setDate(date4);

						// Setting Transaction type.
						String Transactiontype4= "Dr.";
						transaction4.setTransactiontype(Transactiontype4);

						Transaction transferTransaction = service.fundTransfer(accountNoCr,withdrawAmount, transaction4);
						System.out.println("Transaction Details are:" + transferTransaction);
		                }
		                else {
		                	System.out.println("Enter a valid Amount to be withdrawn / Your balance is low.");
		                }
						}catch (Exception e) {
							// TODO: handle exception
			                System.err.println("Enter a valid Account Number");
							}
						break;	
				case 5:
					System.out.println("Your transactions are:");
					System.out.println("-------------------------------------------------");
					try {
					List<Transaction> transactionList = service.printTransactions(account.getAccountNo());
					Iterator<Transaction> iterator = transactionList.iterator();
					while(iterator.hasNext())
					{
						System.out.println(iterator.next());
					}
					}catch (Exception e) {
						// TODO: handle exception
		                System.err.println("No transactions available");
						}
					break;
				case 6:
					System.out.println("Logged out Successfully");
					System.out.println("==================================================================\n");
					System.out.println("Thank You for using UTI Bank Limited's payment system.\n");
					System.out.println("==================================================================");
					sc.close();
					System.exit(0);
		    }
		    	}
		    	    }
		    else {
		    	System.out.println("Invalid Creditentials");
		    }
		    break;
		    
		//Create New Account
		case 2:
			Account bean = new Account();

			// Validating Name
			String name;
			do {
				System.out.println("Enter Your Name");
				name = sc.next();
			} while (!service.validateName(name));
			bean.setName(name);

			// Validating E-mail-ID
			String email;
			do {
				System.out.println("Enter your email id");
				email = sc.next();
			} while (!service.isValidEmailAddress(email));
			bean.setEmailId(email);

			// Address
			System.out.println("Enter your Address");
			String addr = sc.next();
			bean.setAddr(addr);

			//Validating ID Proof Number
			String id;
			do {
				System.out.println("Enter an ID Proof Number(10 digit id)");
				id = sc.next();
			} while (!service.validateId(id));
			bean.setIdProofNo(id);

			// Validating Mobile Number
			String mobile;
			do {
				System.out.println("Enter your Mobile Number");
				mobile = sc.next();
			} while (!service.validateNumber(mobile));
			bean.setMobileNo(mobile);

			// Validating Age
			Integer age;
			do {
				System.out.println("Enter your age");
				age = sc.nextInt();
			} while (!service.validateAge(age));
			bean.setAge(age);

			// Creating AccNo
			Random rnd = new Random();
			Integer accNo = 100000 + rnd.nextInt(900000);
			Long accountNo = (long) accNo;
			bean.setAccountNo(accountNo);

			//Username
			String username;
			System.out.println("Enter a Username");
			username = sc.next();
			bean.setUsername(username);

			// Validating Password
			String password, passwordVer;
			do {
				System.out.println("Create your Password which consists a minimum of 8 characters");
				password = sc.next();
				System.out.println("Re-Enter your Password");
				passwordVer = sc.next();
			} while (!service.validatePassword(password, passwordVer));
			bean.setPassword(password);

			// Validating Balance
			double balance;
			do {
				System.out.println("Enter Account opening balance");
				balance = sc.nextInt();
			} while (!service.validateBalance(balance));
			bean.setBalance(balance);

			// handing objects to bean object after taking input from user
			boolean isAdded = service.addAccount(bean);
			if(isAdded != false) {
			Long a = bean.getAccountNo();
			System.out.println("Congratulations! you have successfully created your account\n");
			System.out.println("Your Account Details are:" + bean);
			System.out.println("Your Account Number is:" + a + "\n");
			}
			break;
        
			
		//Exit
		case 3:
			System.out.println("==================================================================\n");
			System.out.println("Thank You for using UTI Bank Limited's payment system.\n");
			System.out.println("==================================================================");
			sc.close();
			System.exit(0);
			break;
		default:
			break;
		}

	}

}
}