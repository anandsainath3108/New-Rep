package com.capgemini.bankapplication.utility;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtil {
	public static EntityManager getEntityManager() {
		return Persistence.createEntityManagerFactory("BankProject_161680").createEntityManager();
	}
}