package com.capgemini.background;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin={"usage","html:htmlop/html-output"},strict=true,tags={"@Test1"},features={"DemoFeature"},glue={"com.capgemini.bdd2"})
public class TestRunnerMob {

}