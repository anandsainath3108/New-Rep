package com.capgemini.training.stepdef2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.training.pom.ApplicationPageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Experiment2StepDef {
	
	private ApplicationPageFactory factory;
	private WebDriver wd;
		

	@Given("^The user is on the registration home page$")
	public void the_user_is_on_the_registration_home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "D:\\WebDrivers2\\chromedriver.exe");
		wd = new ChromeDriver();

		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		factory = new ApplicationPageFactory(wd);
		wd.get("D:\\Hema_contents\\java_jee\\STS\\ProjectValidations\\WebContent\\Basicform.html");
  
	}

	@When("^The user leaves the username field empty$")
	public void the_user_leaves_the_username_field_empty() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    factory.setUname("");
		factory.setButton();
	}

	@When("^The user clicks the js button$")
	public void the_user_clicks_the_js_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		factory.setButton();
	}

	@Then("^An alert message is displayed$")
	public void an_alert_message_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}

	@Given("^The user has completed the username$")
	public void the_user_has_completed_the_username() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    factory.setUname("ansquared");
	    factory.setCity("Hyderabad");
		factory.setButton();
	}

	@Given("^The user has left the password field empty$")
	public void the_user_has_left_the_password_field_empty() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    factory.setPassword("");
		factory.setButton();
	}

	@Then("^An alert mesasage is displayed$")
	public void an_alert_mesasage_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Given("^The user has left a few fields$")
	public void the_user_has_left_a_few_fields() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	
	}

	@Given("^The user has completed all the other fields$")
	public void the_user_has_completed_all_the_other_fields() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    factory.setPassword("ansquared@1");
	    factory.setRadiobutton1();
		factory.setCheckbox1();
	    factory.setCheckbox2();
		factory.setButton();
	}

	@Given("^The user has filled all the fields$")
	public void the_user_has_filled_all_the_fields() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 factory.setTextarea("Hello and welcome");
		 factory.setCountry();
		 factory.setNumber("10");
		 factory.setEmail("a@gmail.com");
		 factory.setPhonenumber("8885122209");
		 factory.setButton();
	}

	@Then("^Successful registration message is displayed$")
	public void successful_registration_message_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}
}
