package com.capgemini.training.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"usage","html:html-output"},features = {"LabExpFeatureFiles"},glue = {"com.capgemini.training.stepdef"})
public class TestRunner {

}
