package com.capgemini.bdd2;

import java.util.ArrayList;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class mobStepDef {
	
	
	
	List<String> list = new ArrayList<String>();
	
	@Given("^User enter his mobile number$")
	public void user_enter_his_mobile_number(DataTable table) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
		
		list=table.asList(String.class);
		for(String s:list)
		{
			if(s.matches("[6-9][0-9]{9}")) 
			{
				System.out.println("The valid numbers are: "+s);
			}
			else{
				System.out.println("The invalid numbers are: "+s);
			}
		}
		
		
		/*List<List<String>> mobile = table.raw();	
        for(int i=0; i<5; i++) {
		if(mobile.get(i).get(0).matches("[6-9][0-9]{9}"))
		{
			System.out.println("The mobile number is valid "+mobile.get(i).get(0));
		}
		else {
			System.out.println("Mobile nuber is invalid "+mobile.get(i).get(0));
		}
	}*/
}

	@Then("^Display his number is valid or not$")
	public void display_his_number_is_valid_or_not() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}
}
