package com.capgemini.bankapplication.dao;

import java.util.List;

import com.capgemini.bankapplication.entity.Account;
import com.capgemini.bankapplication.entity.Transaction;
import com.capgemini.bankapplication.exception.AccountException;

public interface IAccountDAO {
	public boolean addAccount(Account a) throws AccountException;
	public Account displayAccount(Long accountNo) throws AccountException;
	public Transaction updateAccount(Long accountNoDr, Long accountNoCr, Double transferAmt, Transaction transaction) throws AccountException;
	public List<Transaction> printTransactions(Long accountNo) throws AccountException;
	public Transaction addTransaction(Transaction transaction) throws AccountException;
}
