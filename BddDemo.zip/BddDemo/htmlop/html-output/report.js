$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/capgemini/feature/LoginApplication.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Anand"
    }
  ],
  "line": 3,
  "name": "Login Application",
  "description": "",
  "id": "login-application",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 5,
  "name": "User Logging into an application",
  "description": "",
  "id": "login-application;user-logging-into-an-application",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 7,
  "name": "User enters userName",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "User enters his password",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "userName and Password are valid",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "User is directed to Homepage",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginRegisterStepdef.user_enters_userName()"
});
formatter.result({
  "duration": 95621607,
  "status": "passed"
});
formatter.match({
  "location": "LoginRegisterStepdef.user_enters_his_password()"
});
formatter.result({
  "duration": 57430,
  "status": "passed"
});
formatter.match({
  "location": "LoginRegisterStepdef.username_and_Password_are_valid()"
});
formatter.result({
  "duration": 34048,
  "status": "passed"
});
formatter.match({
  "location": "LoginRegisterStepdef.user_is_directed_to_Homepage()"
});
formatter.result({
  "duration": 32407,
  "status": "passed"
});
formatter.uri("com/capgemini/feature/Register.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Anand"
    }
  ],
  "line": 3,
  "name": "Registration for an application",
  "description": "",
  "id": "registration-for-an-application",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 5,
  "name": "Registering for an online applications",
  "description": "",
  "id": "registration-for-an-application;registering-for-an-online-applications",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 7,
  "name": "User is entering a phoneNumber",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "User is entering a emailId",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "phoneNumber and emailId are valid",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "User is creating a userName and a password",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "User is directed to the login page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginRegisterStepdef.user_is_entering_a_phoneNumber()"
});
formatter.result({
  "duration": 27074,
  "status": "passed"
});
formatter.match({
  "location": "LoginRegisterStepdef.user_is_entering_a_emailId()"
});
formatter.result({
  "duration": 14358,
  "status": "passed"
});
formatter.match({
  "location": "LoginRegisterStepdef.phonenumber_and_emailId_are_valid()"
});
formatter.result({
  "duration": 11076,
  "status": "passed"
});
formatter.match({
  "location": "LoginRegisterStepdef.user_is_creating_a_userName_and_a_password()"
});
formatter.result({
  "duration": 11896,
  "status": "passed"
});
formatter.match({
  "location": "LoginRegisterStepdef.user_is_directed_to_the_login_page()"
});
formatter.result({
  "duration": 11896,
  "status": "passed"
});
});