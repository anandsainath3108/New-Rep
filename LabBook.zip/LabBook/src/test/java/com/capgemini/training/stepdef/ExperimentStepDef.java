package com.capgemini.training.stepdef;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.training.pom.ApplicationPageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ExperimentStepDef {
	
	private ApplicationPageFactory factory;
	private WebDriver wd;
	@Given("^The user is on the registration page$")
	public void the_user_is_on_the_registration_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\WebDrivers2\\chromedriver.exe");
		wd = new ChromeDriver();

		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		factory = new ApplicationPageFactory(wd);
		wd.get("D:\\Hema_contents\\java_jee\\STS\\ProjectValidations\\WebContent\\Basicform.html");
  }

	@When("^The user enters valid username$")
	public void the_user_enters_valid_username() throws Throwable {
	    factory.setUname("ansquared");
	    factory.setCity("Hyderabad");
	}

	@When("^Valid Password$")
	public void valid_Password() throws Throwable {
	    factory.setPassword("ansquared@1");
	}

	@When("^Completes the filling of all fields$")
	public void completes_the_filling_of_all_fields() throws Throwable {
	    factory.setRadiobutton1();
		factory.setCheckbox1();
	    factory.setCheckbox2();
	    factory.setTextarea("Hello and welcome");
	    factory.setCountry();
	    factory.setNumber("10");
	    factory.setEmail("a@gmail.com");
	    factory.setPhonenumber("8885122209");
	}

	@Then("^The user clicks on the button$")
	public void the_user_clicks_on_the_button() throws Throwable {
	    factory.setButton();
	}
	
	@Then("^Alert message is displayed$")
	public void alert_message_is_displayed() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}
}
