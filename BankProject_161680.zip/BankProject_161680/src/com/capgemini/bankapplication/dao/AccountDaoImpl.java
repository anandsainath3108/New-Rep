package com.capgemini.bankapplication.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import com.capgemini.bankapplication.entity.Account;
import com.capgemini.bankapplication.entity.Transaction;
import com.capgemini.bankapplication.exception.AccountException;
import com.capgemini.bankapplication.utility.JPAUtil;

public class AccountDaoImpl implements IAccountDAO {
	EntityManager entityManager = null;

	@Override
	public boolean addAccount(Account account) throws AccountException {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			entityManager.persist(account);
			entityManager.getTransaction().commit();
			flag = true;
		} catch (PersistenceException e) {
			// TODO: Log to file
			throw new AccountException(e.getMessage());
		} finally {

		}
		return flag;
	}

	@Override
	public Account displayAccount(Long accountNo) throws AccountException {
		// TODO Auto-generated method stub
		Account account = null;
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			account = entityManager.find(Account.class, accountNo);
			return account;
		} catch (PersistenceException e) {
			// TODO: Log to file
			throw new AccountException(e.getMessage());
		} finally {

		}
	}

	@Override
	public Transaction updateAccount(Long accountNoDr, Long accountNoCr, Double transferAmt, Transaction transaction)
			throws AccountException {
		// TODO Auto-generated method stub
		Account account1, account2 = null;
		Transaction transaction1;
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();

			// Dr. Account
			  // Debit the amount in the accountDr
			if(accountNoDr!=null) {
				account1 = entityManager.find(Account.class, accountNoDr);
				Double newBalance1 = account1.getBalance() - transferAmt;
				account1.setBalance(newBalance1);
				entityManager.merge(account1);

				// Credit the amount in the accountCr
				}

				// Cr. Account
				if(accountNoCr!=null) {
				account2 = entityManager.find(Account.class, accountNoCr);
				Double newBalance2 = account2.getBalance() + transferAmt;
				account2.setBalance(newBalance2);

				// Credit the amount in the accountCr
				entityManager.merge(account2);

				}
				// Noting the transaction
				entityManager.getTransaction().commit();
				transaction1 = addTransaction(transaction);

				return transaction1;
		    } catch (PersistenceException e) {
			// TODO: Log to file
			throw new AccountException(e.getMessage());
		    } finally {

		    }

	}

	@Override
	public List<Transaction> printTransactions(Long accountNo) throws AccountException {
		// TODO Auto-generated method stub
		EntityManager entityManager = JPAUtil.getEntityManager();
		String jql = "select e from Transaction e where e.accountNoCr=:paccountNo or e.accountNoDr=:paccountNo";
		TypedQuery<Transaction> typedQuery = entityManager.createQuery(jql, Transaction.class);
		typedQuery.setParameter("paccountNo", accountNo);
		List<Transaction> transactionList = typedQuery.getResultList();
	    return transactionList;
	}

	@Override
	public Transaction addTransaction(Transaction transaction) throws AccountException {
		// TODO Auto-generated method stub
		Transaction transaction1 = null;
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			entityManager.persist(transaction);
			entityManager.getTransaction().commit();
			transaction1 = transaction;
		} catch (PersistenceException e) {
			e.printStackTrace();
			// TODO: Log to file
			throw new AccountException(e.getMessage());
		} finally {

		}
		return transaction1;
	}
}