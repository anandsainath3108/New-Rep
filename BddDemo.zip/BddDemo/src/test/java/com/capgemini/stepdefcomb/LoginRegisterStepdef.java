package com.capgemini.stepdefcomb;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginRegisterStepdef {
	@Given("^User enters userName$")
	public void user_enters_userName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Username Entered");
	}

	@Given("^User enters his password$")
	public void user_enters_his_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Password Entered");
	}

	@When("^userName and Password are valid$")
	public void username_and_Password_are_valid() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Username and Password are valid");
	}

	@Then("^User is directed to Homepage$")
	public void user_is_directed_to_Homepage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("You are directed to your homepage");
	}
	@Given("^User is entering a phoneNumber$")
	public void user_is_entering_a_phoneNumber() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Given("^User is entering a emailId$")
	public void user_is_entering_a_emailId() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^phoneNumber and emailId are valid$")
	public void phonenumber_and_emailId_are_valid() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Given("^User is creating a userName and a password$")
	public void user_is_creating_a_userName_and_a_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^User is directed to the login page$")
	public void user_is_directed_to_the_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}
}
