$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Experiment3.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Anand Sainath Pendyala"
    }
  ],
  "line": 2,
  "name": "Testing the working of a registration page",
  "description": "",
  "id": "testing-the-working-of-a-registration-page",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "Unsuccessful registration due to username field empty",
  "description": "",
  "id": "testing-the-working-of-a-registration-page;unsuccessful-registration-due-to-username-field-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "The user is already on the registration home page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "The user leaves the username field blank",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "The user clicks the button",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "An alert is displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "Experiment3StepDef.the_user_is_already_on_the_registration_home_page()"
});
formatter.result({
  "duration": 3739123782,
  "status": "passed"
});
formatter.match({
  "location": "Experiment3StepDef.the_user_leaves_the_username_field_blank()"
});
formatter.result({
  "duration": 69291932,
  "status": "passed"
});
formatter.match({
  "location": "Experiment3StepDef.the_user_clicks_the_button()"
});
formatter.result({
  "duration": 58348337,
  "status": "passed"
});
formatter.match({
  "location": "Experiment3StepDef.an_alert_is_displayed()"
});
formatter.result({
  "duration": 6158167721,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Unsuccessful registration due to password field empty",
  "description": "",
  "id": "testing-the-working-of-a-registration-page;unsuccessful-registration-due-to-password-field-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "The user has already entered the username",
  "keyword": "Given "
});
formatter.step({
  "line": 12,
  "name": "The user has already entered the city",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "The user leaves the password field blank",
  "keyword": "When "
});
formatter.step({
  "line": 14,
  "name": "The user clicks the button",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "An alert is displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "Experiment3StepDef.the_user_has_already_entered_the_username()"
});
formatter.result({
  "duration": 3365593926,
  "status": "passed"
});
formatter.match({
  "location": "Experiment3StepDef.the_user_has_already_entered_the_city()"
});
formatter.result({
  "duration": 75179682,
  "status": "passed"
});
formatter.match({
  "location": "Experiment3StepDef.the_user_leaves_the_password_field_blank()"
});
formatter.result({
  "duration": 49613315,
  "status": "passed"
});
formatter.match({
  "location": "Experiment3StepDef.the_user_clicks_the_button()"
});
formatter.result({
  "duration": 76066967,
  "status": "passed"
});
formatter.match({
  "location": "Experiment3StepDef.an_alert_is_displayed()"
});
formatter.result({
  "duration": 4205558106,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "Unsuccessful registration due to fields left empty",
  "description": "",
  "id": "testing-the-working-of-a-registration-page;unsuccessful-registration-due-to-fields-left-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 18,
  "name": "The user has completed most of the fields",
  "keyword": "Given "
});
formatter.step({
  "line": 19,
  "name": "The user has forgot to enter some of the fields",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "The user clicks the button",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "An alert is displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "Experiment3StepDef.the_user_has_completed_most_of_the_fields()"
});
formatter.result({
  "duration": 3885181270,
  "status": "passed"
});
formatter.match({
  "location": "Experiment3StepDef.the_user_has_forgot_to_enter_some_of_the_fields()"
});
formatter.result({
  "duration": 15178,
  "status": "passed"
});
formatter.match({
  "location": "Experiment3StepDef.the_user_clicks_the_button()"
});
formatter.result({
  "duration": 68259842,
  "status": "passed"
});
formatter.match({
  "location": "Experiment3StepDef.an_alert_is_displayed()"
});
formatter.result({
  "duration": 4158515990,
  "status": "passed"
});
formatter.scenario({
  "line": 23,
  "name": "Successful registration",
  "description": "",
  "id": "testing-the-working-of-a-registration-page;successful-registration",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 24,
  "name": "The user has entered the valid details for all the fields",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "The user clicks the button",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "Successful submission alert is shown",
  "keyword": "Then "
});
formatter.match({
  "location": "Experiment3StepDef.the_user_has_entered_the_valid_details_for_all_the_fields()"
});
formatter.result({
  "duration": 3937996277,
  "status": "passed"
});
formatter.match({
  "location": "Experiment3StepDef.the_user_clicks_the_button()"
});
formatter.result({
  "duration": 60745196,
  "status": "passed"
});
formatter.match({
  "location": "Experiment3StepDef.successful_submission_alert_is_shown()"
});
formatter.result({
  "duration": 4014298706,
  "status": "passed"
});
});