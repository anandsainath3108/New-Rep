$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Experiment.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Anand Sainath Pendyala"
    }
  ],
  "line": 3,
  "name": "Filling up the registration form.",
  "description": "",
  "id": "filling-up-the-registration-form.",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 5,
  "name": "Registering with valid detalis",
  "description": "",
  "id": "filling-up-the-registration-form.;registering-with-valid-detalis",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "The user is on the registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "The user enters valid username",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Valid Password",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Completes the filling of all fields",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "The user clicks on the button",
  "keyword": "Then "
});
formatter.match({
  "location": "ExperimentStepDef.the_user_is_on_the_registration_page()"
});
formatter.result({
  "duration": 3957546498,
  "status": "passed"
});
formatter.match({
  "location": "ExperimentStepDef.the_user_enters_valid_username()"
});
formatter.result({
  "duration": 173856631,
  "status": "passed"
});
formatter.match({
  "location": "ExperimentStepDef.valid_Password()"
});
formatter.result({
  "duration": 76631417,
  "status": "passed"
});
formatter.match({
  "location": "ExperimentStepDef.completes_the_filling_of_all_fields()"
});
formatter.result({
  "duration": 1886575575,
  "status": "passed"
});
formatter.match({
  "location": "ExperimentStepDef.the_user_clicks_on_the_button()"
});
formatter.result({
  "duration": 89067358,
  "status": "passed"
});
});