function chkEmpty() {

	/*
	 * if (document.frm1.userName.value == "") {alert("Please fill the First
	 * Name");} if (document.frm1.city.value == "") {alert("Please fill the
	 * city");} if (document.frm1.password.value == "") {alert("Please fill the
	 * password");} if (document.frm1.gender.value !="M" ||
	 * document.frm1.gender.value !="F" ) {alert("Gender must be selected");} if
	 * (document.frm1.lang.value !="Eng" || document.frm1.lang.value !="Tel" ||
	 * document.frm1.lang.value !="Tam" ) {alert("Atleast 1 language must be
	 * selected");}
	 */
	if (document.frm1.userName.value == "" || document.frm1.city.value == ""
			|| document.frm1.password.value == ""
			|| document.frm1.gender.value != "M"
			|| document.frm1.gender.value != "F"
			|| document.frm1.lang.value != "Eng"
			|| document.frm1.lang.value != "Tel"
			|| document.frm1.lang.value != "Tam") {
		alert("Fill all the fields")
	} else {
		alert(" completed Successfully.");
	}
}