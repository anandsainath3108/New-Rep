$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("mobDemo.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Anand"
    }
  ],
  "line": 2,
  "name": "Mobile Number Validation",
  "description": "",
  "id": "mobile-number-validation",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "Application verifies mobile numbers",
  "description": "",
  "id": "mobile-number-validation;application-verifies-mobile-numbers",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@Test1"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "User enter his mobile number",
  "rows": [
    {
      "cells": [
        "\u00277894561230\u0027"
      ],
      "line": 7
    },
    {
      "cells": [
        "\u00275674561230\u0027"
      ],
      "line": 8
    },
    {
      "cells": [
        "\u00278974561230\u0027"
      ],
      "line": 9
    },
    {
      "cells": [
        "\u00279874561230\u0027"
      ],
      "line": 10
    },
    {
      "cells": [
        "\u00276484561230\u0027"
      ],
      "line": 11
    }
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 12,
  "name": "Display his number is valid or not",
  "keyword": "Then "
});
formatter.match({
  "location": "mobStepDef.user_enter_his_mobile_number(DataTable)"
});
formatter.result({
  "duration": 91138198,
  "status": "passed"
});
formatter.match({
  "location": "mobStepDef.display_his_number_is_valid_or_not()"
});
formatter.result({
  "duration": 14359,
  "status": "passed"
});
});