package com.capgemini.training.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"usage","html:html-output"},features = {"LabExpFeatures3"},glue = {"com.capgemini.training.stepdef3"})
public class TestRunner3 {

}