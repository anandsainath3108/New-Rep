package com.capgemini.bdd;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin={"usage","html:htmlop/html-output"},features={"src/main/java"},glue={"com.capgemini.stepdefcomb"})
public class TestRunnerComb {

}