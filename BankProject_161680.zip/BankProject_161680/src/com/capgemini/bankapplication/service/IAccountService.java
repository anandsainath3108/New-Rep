package com.capgemini.bankapplication.service;

import java.util.List;

import com.capgemini.bankapplication.entity.Account;
import com.capgemini.bankapplication.entity.Transaction;
import com.capgemini.bankapplication.exception.AccountException;

public interface IAccountService {
	public boolean addAccount(Account a) throws AccountException;
	public Account displayAccount(Long accountNo) throws AccountException;
	public Transaction deposit(Double depositAmount, Transaction transaction) throws AccountException;
	public Transaction withdraw(Double withdrawAmount, Transaction transaction) throws AccountException;
	public Transaction fundTransfer(Long accountNoCr, Double transferAmt, Transaction transaction) throws AccountException;
	public List<Transaction> printTransactions(Long accountNo) throws AccountException;
}
