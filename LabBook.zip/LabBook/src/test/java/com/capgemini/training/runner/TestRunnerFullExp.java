package com.capgemini.training.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"usage","html:html-output"},features = {"LabExpFeatures2"},glue = {"com.capgemini.training.stepdef2"})
public class TestRunnerFullExp {
}
