package com.capgemini.stepdef;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegisterStepDef {
	@Given("^User is entering a phoneNumber$")
	public void user_is_entering_a_phoneNumber() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Given("^User is entering a emailId$")
	public void user_is_entering_a_emailId() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^phoneNumber and emailId are valid$")
	public void phonenumber_and_emailId_are_valid() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Given("^User is creating a userName and a password$")
	public void user_is_creating_a_userName_and_a_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^User is directed to the login page$")
	public void user_is_directed_to_the_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}
}
