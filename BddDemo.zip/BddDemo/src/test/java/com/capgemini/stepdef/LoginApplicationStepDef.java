package com.capgemini.stepdef;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginApplicationStepDef {

	@Given("^User enters userName$")
	public void user_enters_userName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Username Entered");
	}

	@Given("^User enters his password$")
	public void user_enters_his_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Password Entered");
	}

	@When("^userName and Password are valid$")
	public void username_and_Password_are_valid() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Username and Password are valid");
	}

	@Then("^User is directed to Homepage$")
	public void user_is_directed_to_Homepage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("You are directed to your homepage");
	}

}
