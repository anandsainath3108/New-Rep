package com.capgemini.training.stepdef3;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.training.pom.ApplicationPageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Experiment3StepDef {
	
	private ApplicationPageFactory factory;
	private WebDriver wd;
    
	
	@Given("^The user is already on the registration home page$")
	public void the_user_is_already_on_the_registration_home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "D:\\WebDrivers2\\chromedriver.exe");
		wd = new ChromeDriver();

		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		factory = new ApplicationPageFactory(wd);
		wd.get("D:\\Hema_contents\\java_jee\\STS\\ProjectValidations\\WebContent\\Basicform.html");
	}

	@When("^The user leaves the username field blank$")
	public void the_user_leaves_the_username_field_blank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		factory.setUname("");
	}

	@When("^The user clicks the button$")
	public void the_user_clicks_the_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    factory.setButton();
	}

	@Then("^An alert is displayed$")
	public void an_alert_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}
	
	@Given("^The user has already entered the username$")
	public void the_user_has_already_entered_the_username() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "D:\\WebDrivers2\\chromedriver.exe");
		wd = new ChromeDriver();

		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		factory = new ApplicationPageFactory(wd);
		wd.get("D:\\Hema_contents\\java_jee\\STS\\ProjectValidations\\WebContent\\Basicform.html"); 
		factory.setUname("ansquared");
	}

	@Given("^The user has already entered the city$")
	public void the_user_has_already_entered_the_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 factory.setCity("Hyderabad");
	}
	
	@When("^The user leaves the password field blank$")
	public void the_user_leaves_the_password_field_blank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 factory.setPassword("");
	}
	@Given("^The user has completed most of the fields$")
	public void the_user_has_completed_most_of_the_fields() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "D:\\WebDrivers2\\chromedriver.exe");
		wd = new ChromeDriver();

		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		factory = new ApplicationPageFactory(wd);
		wd.get("D:\\Hema_contents\\java_jee\\STS\\ProjectValidations\\WebContent\\Basicform.html");
		factory.setUname("ansquared");
	    factory.setCity("Bangalore");
	    factory.setPassword("ansquared@1");
		factory.setTextarea("Hello and welcome");
	    factory.setCountry();
	    factory.setNumber("10");
	    factory.setEmail("a@gmail.com");
	    factory.setPhonenumber("8885122209");
	}

	@When("^The user has forgot to enter some of the fields$")
	public void the_user_has_forgot_to_enter_some_of_the_fields() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Given("^The user has entered the valid details for all the fields$")
	public void the_user_has_entered_the_valid_details_for_all_the_fields() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "D:\\WebDrivers2\\chromedriver.exe");
		wd = new ChromeDriver();

		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		factory = new ApplicationPageFactory(wd);
		wd.get("D:\\Hema_contents\\java_jee\\STS\\ProjectValidations\\WebContent\\Basicform.html"); 
		factory.setUname("ansquared");
		factory.setCity("Mumbai");
		factory.setPassword("ansquared@1");
		factory.setRadiobutton1();
		factory.setCheckbox1();
		factory.setCheckbox2();
	    factory.setTextarea("Hello and welcome");
 	    factory.setCountry();
	    factory.setNumber("10");
		factory.setEmail("a@gmail.com");
	    factory.setPhonenumber("8885122209");
	}

	@Then("^Successful submission alert is shown$")
	public void successful_submission_alert_is_shown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
	}
}
