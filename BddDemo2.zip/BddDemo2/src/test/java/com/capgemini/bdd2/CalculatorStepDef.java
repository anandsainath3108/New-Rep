package com.capgemini.bdd2;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CalculatorStepDef {

	@Given("^Add two numbers$")
	public void add_two_numbers() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		int a=1230, b=253;
		int c = a+b;
		the_numbers_are_and(a,b);
		display_the_result_in(c);
	}

	@When("^the numbers are (\\d+) and (\\d+)$")
	public void the_numbers_are_and(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("The numbers are:"+arg1+"and"+arg2);
	}

	@Then("^display the result in (\\d+)$")
	public void display_the_result_in(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("The numbers are:"+arg1);
    }

	@Given("^Subract two numbers$")
	public void subract_two_numbers() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		int a=1230, b=253;
		int c = a-b;
		the_numbers_are_and(a,b);
		display_the_result_in(c);
	}

	@Given("^Multiply two numbers$")
	public void multiply_two_numbers() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		int a=1230, b=253;
		int c = a*b;
		the_numbers_are_and(a,b);
		display_the_result_in(c);
	}

	@Given("^Divide two numbers$")
	public void divide_two_numbers() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		int a=1230, b=253;
		int c = a/b;
		the_numbers_are_and(a,b);
		display_the_result_in(c);
	}
}