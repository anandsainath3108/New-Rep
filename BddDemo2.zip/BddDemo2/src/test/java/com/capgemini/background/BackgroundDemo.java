package com.capgemini.background;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BackgroundDemo {
	@Given("^User typed his username and password$")
	public void user_typed_his_username_and_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("1");
	}

	@When("^Username and password are correct$")
	public void username_and_password_are_correct() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("2");
	}

	@Then("^User is on the home page$")
	public void user_is_on_the_home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("3");
	}

	@Given("^username and password are right$")
	public void username_and_password_are_right() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("4");
	}

	@Given("^user has created a new password$")
	public void user_has_created_a_new_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("5");
    }
}
