package com.capgemini.training.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ApplicationPageFactory {
		WebDriver wd;

		// initiating Elements
		public ApplicationPageFactory(WebDriver webdriver) {
			this.wd = webdriver;
			PageFactory.initElements(wd, this);
		}

		@FindBy(name = "userName")
		@CacheLookup
		WebElement uname;
		
		@FindBy(name = "city")
		@CacheLookup
		WebElement city;

		@FindBy(name = "password")
		@CacheLookup
		WebElement password;

		@FindBy(xpath="/html/body/center/form/input[5]")
		@CacheLookup
		WebElement radiobutton1;

		@FindBy(xpath="/html/body/center/form/input[7]")
		@CacheLookup
		WebElement checkbox1;
		
		@FindBy(xpath="/html/body/center/form/input[8]")
		@CacheLookup
		WebElement checkbox2;
		
		@FindBy(xpath="/html/body/center/form/textarea")
		@CacheLookup
		WebElement textarea;
		
		@FindBy(xpath="/html/body/center/form/select/option[4]")
		@CacheLookup
		WebElement country;
		
		@FindBy(xpath="/html/body/center/form/input[11]")
		@CacheLookup
		WebElement number;
		
		@FindBy(xpath="/html/body/center/form/input[12]")
		@CacheLookup
		WebElement email;	
		
		@FindBy(xpath="/html/body/center/form/input[13]")
		@CacheLookup
		WebElement phonenumber;
		
		@FindBy(xpath="/html/body/center/form/button")
		@CacheLookup
		WebElement button;

		public void setUname(String uname) {
			this.uname.sendKeys(uname);
		}

		public void setCity(String city) {
			this.city.sendKeys(city);
}

		public void setPassword(String password) {
			this.password.sendKeys(password);
       }

		public void setRadiobutton1() {
			radiobutton1.click();
		}

		public void setCheckbox1() {
			checkbox1.click();
		}

		public void setCheckbox2() {
			checkbox2.click();
		}

		public void setTextarea(String textarea) {
			this.textarea.sendKeys(textarea);
		}

		public void setCountry() {
			country.click();
		}

		public void setNumber(String number) {
			this.number.sendKeys(number);
		}

		public void setEmail(String email) {
			this.email.sendKeys(email);
		}

		public void setPhonenumber(String phonenumber) {
			this.phonenumber.sendKeys(phonenumber);
		}

		public void setButton() {
			button.click();
		}

		public WebElement getUname() {
			return uname;
		}

		public WebElement getCity() {
			return city;
		}

		public WebElement getPassword() {
			return password;
		}

		public WebElement getTextarea() {
			return textarea;
		}

		public WebElement getNumber() {
			return number;
		}

		public WebElement getEmail() {
			return email;
		}

		public WebElement getPhonenumber() {
			return phonenumber;
		}

		public WebElement getRadiobutton1() {
			return radiobutton1;
		}

		public WebElement getCheckbox1() {
			return checkbox1;
		}

		public WebElement getCheckbox2() {
			return checkbox2;
		}

		public WebElement getCountry() {
			return country;
		}

		public WebElement getButton() {
			return button;
		}
}

